# Load required libraries
library(dplyr)
library(ggplot2)

# Read the data from the CSV file
olympic_data <- read.csv("olympic_data.csv")

# Explore the data
str(olympic_data)  # Structure of the dataset
summary(olympic_data)  # Summary statistics

# Check for missing values
colSums(is.na(olympic_data))

# Example of data cleaning: Remove rows with missing values in Age
olympic_data_clean <- olympic_data %>%
  filter(!is.na(Age))

# Data Analysis: Count medals by country
medals_by_country <- olympic_data_clean %>%
  group_by(Country) %>%
  summarise(Total_Gold = sum(Gold, na.rm = TRUE),
            Total_Silver = sum(Silver, na.rm = TRUE),
            Total_Bronze = sum(Bronze, na.rm = TRUE),
            Total_Medals = sum(Total_medals, na.rm = TRUE), 
            .groups = 'drop') %>%
  arrange(desc(Total_Medals))

# Print the top 10 countries with the most medals
print(head(medals_by_country, 10))

# Data Visualization: Medals won by country
ggplot(medals_by_country, aes(x = reorder(Country, Total_Medals), y = Total_Medals, fill = Country)) +
  geom_bar(stat = "identity") +
  coord_flip() +
  labs(title = "Total Medals Won by Country", x = "Country", y = "Total Medals") +
  theme_minimal()
