# Load necessary libraries
library(ggplot2)

# Read the CSV file
data <- read.csv("satgpa.csv")





# Create histograms for each variable
par(mfrow = c(3, 2))  # Set the layout for multiple plots

# Histogram for verbal SAT percentile
hist(data$sat_v, main = "Verbal SAT Percentile", xlab = "SAT Verbal", col = "lightblue", border = "black")

# Histogram for math SAT percentile
hist(data$sat_m, main = "Math SAT Percentile", xlab = "SAT Math", col = "lightgreen", border = "black")

# Histogram for total SAT percentile
hist(data$sat_sum, main = "Total SAT Percentile", xlab = "Total SAT", col = "lightcoral", border = "black")

# Histogram for high school GPA
hist(data$hs_gpa, main = "High School GPA", xlab = "High School GPA", col = "lightyellow", border = "black")

# Histogram for first year GPA
hist(data$fy_gpa, main = "First Year GPA", xlab = "First Year GPA", col = "lightpink", border = "black")








# Create data frames for male and female students
sex_m <- data[data$sex == "M", ]
sex_f <- data[data$sex == "F", ]







# Number of students in each data frame
num_males <- nrow(sex_m)
num_females <- nrow(sex_f)

cat("Number of male students:", num_males, "\n")
cat("Number of female students:", num_females, "\n")









# Function to calculate mean, variance, and median
calculate_stats <- function(df) {
  mean_val <- mean(df$sat_sum)
  var_val <- var(df$sat_sum)
  median_val <- median(df$sat_sum)
  
  return(c(mean = mean_val, variance = var_val, median = median_val))
}

# Calculate for males and females
stats_males <- calculate_stats(sex_m)
stats_females <- calculate_stats(sex_f)

cat("Male SAT Stats: Mean =", stats_males["mean"], ", Variance =", stats_males["variance"], ", Median =", stats_males["median"], "\n")
cat("Female SAT Stats: Mean =", stats_females["mean"], ", Variance =", stats_females["variance"], ", Median =", stats_females["median"], "\n")








# Calculate mean and standard deviation for males and females
mean_m <- stats_males["mean"]
mean_f <- stats_females["mean"]
sd_m <- sqrt(stats_males["variance"])
sd_f <- sqrt(stats_females["variance"])

# Number of students
n_m <- num_males
n_f <- num_females

# Calculate the standard error of the difference in means
se_diff <- sqrt((sd_m^2 / n_m) + (sd_f^2 / n_f))

# Calculate the z-value for a 90% confidence interval
z_value <- qnorm(0.95)  # 90% CI corresponds to 95th percentile for one-sided test

# Confidence interval for the difference in means
ci_lower <- (mean_m - mean_f) - z_value * se_diff
ci_upper <- (mean_m - mean_f) + z_value * se_diff

cat("90% Confidence Interval for the difference in means (μ1 - μ2):", ci_lower, "to", ci_upper, "\n")








# Conduct a t-test to test the hypothesis
t_test_result <- t.test(sex_m$sat_sum, sex_f$sat_sum, alternative = "greater")

# Print the results of the t-test
cat("t-test result:\n")
print(t_test_result)
