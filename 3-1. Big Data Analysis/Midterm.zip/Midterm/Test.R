data <- read.csv("satgpa.csv")

head(data)




# Creating histograms for each variable in the data
# Assuming the dataframe 'data' is already loaded

# Histogram for sex (if categorical, a bar plot may be more appropriate)
hist(data$sex, main = "Hist of Sex", 
     xlab = "Gender of the student (1=Male, 2=Female)", col = "lightgray", border = "black")

# Histogram for sat_v (Verbal SAT Percentile)
hist(data$sat_v, main = "Hist of sat_v", 
     xlab = "Verbal SAT percentile", col = "lightblue", border = "black")

# Histogram for sat_m (Math SAT Percentile)
hist(data$sat_m, main = "Hist of sat_m", 
     xlab = "Math SAT percentile", col = "lightgreen", border = "black")

# Histogram for sat_sum (Total SAT Percentile)
hist(data$sat_sum, main = "Hist of sat_sum", 
     xlab = "Total of verbal and math SAT percentiles", col = "lightcoral", border = "black")

# Histogram for hs_gpa (High School GPA)
hist(data$hs_gpa, main = "Hist of hs_gpa", 
     xlab = "High school grade point average", col = "lightyellow", border = "black")

# Histogram for fy_gpa (First Year GPA)
hist(data$fy_gpa, main = "Hist of fy_gpa", 
     xlab = "First year (college) grade point average", col = "lightpink", border = "black")




# Creating data frame for male students (sex = 1)
sex_m <- subset(data, sex == 1)

# Creating data frame for female students (sex = 2)
sex_f <- subset(data, sex == 2)

# Display the first few rows of each to verify
head(sex_m)
head(sex_f)




# Finding the number of male students
num_male_students <- nrow(sex_m)

# Finding the number of female students
num_female_students <- nrow(sex_f)

# Print the results
cat("Number of male students:", num_male_students, "\n")
cat("Number of female students:", num_female_students, "\n")




# For male students (sex_m)
mean_male_sat_sum <- mean(sex_m$sat_sum)
var_male_sat_sum <- var(sex_m$sat_sum)
median_male_sat_sum <- median(sex_m$sat_sum)

# For female students (sex_f)
mean_female_sat_sum <- mean(sex_f$sat_sum)
var_female_sat_sum <- var(sex_f$sat_sum)
median_female_sat_sum <- median(sex_f$sat_sum)

# Print the results for male students
cat("Male students - SAT Sum:\n")
cat("Mean:", mean_male_sat_sum, "\n")
cat("Variance:", var_male_sat_sum, "\n")
cat("Median:", median_male_sat_sum, "\n\n")

# Print the results for female students
cat("Female students - SAT Sum:\n")
cat("Mean:", mean_female_sat_sum, "\n")
cat("Variance:", var_female_sat_sum, "\n")
cat("Median:", median_female_sat_sum, "\n")




# Calculate the necessary values
mean_male <- mean(sex_m$sat_sum)
mean_female <- mean(sex_f$sat_sum)

var_male <- var(sex_m$sat_sum)
var_female <- var(sex_f$sat_sum)

n_male <- nrow(sex_m)
n_female <- nrow(sex_f)

# Calculate the standard error of the difference
se_diff <- sqrt((var_male / n_male) + (var_female / n_female))

# Calculate degrees of freedom using Welch-Satterthwaite equation
df <- ( (var_male / n_male) + (var_female / n_female) )^2 / 
  ( ((var_male / n_male)^2 / (n_male - 1)) + ((var_female / n_female)^2 / (n_female - 1)) )

# Find the critical value for 90% confidence interval (alpha = 0.10, two-tailed)
alpha <- 0.10
t_critical <- qt(1 - alpha / 2, df)

# Calculate the margin of error
margin_error <- t_critical * se_diff

# Calculate the confidence interval
lower_bound <- (mean_male - mean_female) - margin_error
upper_bound <- (mean_male - mean_female) + margin_error

# Print the results
cat("90% Confidence Interval for the difference (μ1 - μ2):\n")
cat("Lower bound:", lower_bound, "\n")
cat("Upper bound:", upper_bound, "\n")






# Perform one-tailed Welch t-test
t_test_result <- t.test(sex_m$sat_sum, sex_f$sat_sum, 
                        alternative = "greater", # One-tailed test
                        var.equal = FALSE,       # Unequal variance
                        conf.level = 0.95)       # 5% significance level

# Print the test result
print(t_test_result)






