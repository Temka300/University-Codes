install.packages("dplyr")

library(dplyr)

summary(mtcars)

install.packages("ggplot2")

library(ggplot2)
library(dplyr)

